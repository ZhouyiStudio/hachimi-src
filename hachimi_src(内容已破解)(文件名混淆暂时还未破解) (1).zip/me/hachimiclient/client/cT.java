/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.hachimiclient.client.\u0000ji\u200e
 *  net.minecraft.class_2596
 */
package me.hachimiclient.client;

import me.hachimiclient.client.\u0000ji\u200e;
import net.minecraft.class_2596;

@\u0000ji\u200e
public interface cT {
    public /* synthetic */ void vS(class_2596 var1);
}

