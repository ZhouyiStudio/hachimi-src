/*
 * Decompiled with CFR 0.152.
 */
package me.hachimiclient.client;

public interface aQ {
    public /* synthetic */ String iy();
}

