/*
 * Decompiled with CFR 0.152.
 */
package me.hachimiclient.client;

public interface eR {
    public static final /* synthetic */ long d;

    public /* synthetic */ void IL();

    public /* synthetic */ void IN(Number var1);

    public /* synthetic */ long IM();

    public /* synthetic */ boolean IK(Number var1);

    static {
        d = -255L;
    }
}

