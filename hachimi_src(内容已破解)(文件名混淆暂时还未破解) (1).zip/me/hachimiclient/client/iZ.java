/*
 * Decompiled with CFR 0.152.
 */
package me.hachimiclient.client;

public interface iZ {
    public /* synthetic */ boolean aeG();

    public /* synthetic */ void aeH(boolean var1);
}

