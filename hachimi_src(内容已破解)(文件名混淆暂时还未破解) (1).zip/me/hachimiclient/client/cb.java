/*
 * Decompiled with CFR 0.152.
 */
package me.hachimiclient.client;

import me.hachimiclient.client.jU;

public interface cb {
    public /* synthetic */ void onPress(jU var1);
}

