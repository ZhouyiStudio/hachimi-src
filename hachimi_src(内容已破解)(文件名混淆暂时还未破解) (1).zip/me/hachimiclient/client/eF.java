/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.hachimiclient.client.\u0000ji\u200e
 */
package me.hachimiclient.client;

import me.hachimiclient.client.\u0000ji\u200e;

@\u0000ji\u200e
public interface eF {
    public /* synthetic */ void GY();

    public /* synthetic */ void GZ();
}

