/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.hachimiclient.client.\u0000ji\u200e
 *  net.minecraft.class_276
 */
package me.hachimiclient.client;

import me.hachimiclient.client.\u0000ji\u200e;
import net.minecraft.class_276;

@\u0000ji\u200e
public interface im {
    public /* synthetic */ void ZR(String var1, class_276 var2);
}

